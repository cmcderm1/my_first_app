default['nodejs']['npm']['install_method'] = 'embedded'
default['nodejs']['npm']['version'] = 'latest'
